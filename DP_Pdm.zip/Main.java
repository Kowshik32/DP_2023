import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        while(true){

            Toll_Collectior_Officer_Access tt1 = new Toll_Collectior_Officer_Access();
            System.out.println("Press 1 for login & enter into the system ");
            Scanner sc = new Scanner(System.in);
            int choice = sc.nextInt();
            if (choice == 1) {
                tt1.login();
                break;
            }
            else {
                System.out.println("invalid choice");
            }
        }
    }


}






