import java.util.Scanner;


public class Toll_Collectior_Officer_Access {

    public static Toll_Collectior_Officer_Access instance;
    Toll_Collectior_Officer_Access(){};
static Toll_Collector_Officer t2 = new Toll_Collector_Officer();
    public  static Toll_Collectior_Officer_Access getInstance()
    {
        if(instance == null )
        {
            instance = new Toll_Collectior_Officer_Access();
        }
        return instance;
    }
    public static void login() {



        Scanner sc = new Scanner(System.in);
        while(true) {
            System.out.println("Enter the username :");
            String username = sc.nextLine();
            System.out.println("Enter the password :");
            String password = sc.nextLine();
            if (username.equals("kowshik") && password.equals("777")) {
                System.out.println("!!!(login successful)!!!");
                t2.menu();
                break;
            }
        }
    }

    private void menu() {
    }
}







