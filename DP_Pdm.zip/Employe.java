public class Employe extends Admin {

    int Motorcycle1 = 0;
    int Car1 =0;
    int Pickup1 =0;
    int Microbus1 =0;
    int Minibus1 =0;
    int Mediumbus1 =0;
    int Bigbus1 = 0;
    int TruckFivetonnes1 =0;
    int TruckEighttonnes1=0;
    int Truck3ax1=0;
    int Trailer4axle1=0;

    @Override
    void calculate()
    {
        System.out.println("___________________________________");

        System.out.println("    \tDay Report Sheet\t    ");

        System.out.println("     \tVehicales List\t      ");

        System.out.println("___________________________________");

        System.out.println("1.Motorcycle         : "+Motorcycle1);
        System.out.println("2.Car/Jeep           : "+Car1);
        System.out.println("3.Pickup             : "+Pickup1);
        System.out.println("4.Micro bus          : "+Microbus1);
        System.out.println("5.Minibus            : "+Minibus1);
        System.out.println("6.Medium bus         : "+Mediumbus1);
        System.out.println("7.Big bus            : "+Bigbus1);
        System.out.println("8.Truck(upto5 tonnes : "+TruckFivetonnes1);
        System.out.println("9.Truck(5-8 tonnes)  : "+TruckEighttonnes1);
        System.out.println("10.Truck (3 axle)    : "+Truck3ax1);
        System.out.println("11.Trailer(4 axle)   : "+Trailer4axle1);

        System.out.println("____________________________________");

        System.out.println("Toll Amount of Spacific Vehicals");

        System.out.println("__________________________________");

    }


}
