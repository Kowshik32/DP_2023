import java.util.Scanner;

public class Toll_Collector_Officer {

    Toll_Collectior_Officer_Access T1 = Toll_Collectior_Officer_Access.getInstance();
    

    public static void menu() {
        while (true) {
            System.out.println("\t\t\t\t\t\t\t\t\t $$The menu of this system$$ ");
            System.out.println("\t\t\t\t\t\t\t\t\t Press 1 for View Toll List ");
            System.out.println("\t\t\t\t\t\t\t\t\t Press 2 for Toll Entry");
            System.out.println("\t\t\t\t\t\t\t\t\t press 3 for exit.....");
            System.out.println("\t\t\t\t\t\t\t\t\t Enter your choice? ");
            Scanner pc = new Scanner(System.in);
            int j = pc.nextInt();
            if(j==1) {
                Admin c1 = new Admin();
                c1.viewtolllist();
            }
            else if (j == 2) {
                Admin c2 = new Admin();
                c2.calculate();
                Scanner scanner = new Scanner(System.in);
              Payment v1 = new Payment();
                Employe vc = new Employe();
                int total = 0;
                while (true) {
                    System.out.println("Enter the choice of varicales:");
                    int choice = scanner.nextInt();
                    if (choice == 0) break;
                    switch (choice) {
                        case 1: {
                            v1.setMotorcycle(100);
                            vc.Motorcycle1 = vc.Motorcycle1 + 1;
                            v1.mtk = v1.mtk + v1.getMotorcycle();
                            total = total + v1.getMotorcycle();
                            break;
                        }
                        case 2: {
                            vc.Car1 = vc.Car1 + 1;
                            v1.ctk = v1.ctk + v1.Car;
                            total = total + v1.Car;
                            break;
                        }
                        case 3: {
                            vc.Pickup1 = vc.Pickup1 + 1;
                            v1.ptk = v1.ptk + v1.Pickup;
                            total = total + v1.Pickup;
                            break;
                        }
                        case 4: {
                            vc.Microbus1 = vc.Microbus1 + 1;
                            v1.mitk = v1.mitk + v1.Mediumbus;
                            total = total + v1.Microbus;
                            break;
                        }
                        case 5: {
                            vc.Minibus1 = vc.Minibus1 + 1;
                            v1.mbtk = v1.mbtk + v1.Minibus;
                            total = total + v1.Minibus;
                            break;
                        }
                        case 6: {
                            vc.Mediumbus1 = vc.Mediumbus1+ 1;
                            v1.mdbtk = v1.mdbtk + v1.Mediumbus;
                            total = total + v1.Mediumbus;
                            break;
                        }
                        case 7: {
                            vc.Bigbus1 = vc.Bigbus1 + 1;
                            v1.bbtk = v1.bbtk + v1.Bigbus;
                            total = total + v1.Bigbus;
                            break;
                        }
                        case 8: {
                            vc.TruckFivetonnes1 = vc.TruckFivetonnes1 + 1;
                            v1.tftk = v1.tftk + v1.TruckFivetonnes;
                            total = total + v1.TruckFivetonnes;
                            break;
                        }
                        case 9: {
                            vc.TruckEighttonnes1 = vc.TruckEighttonnes1 + 1;
                            v1.tetk = v1.tetk + v1.TruckEighttonnes;
                            total = total + v1.TruckEighttonnes;
                            break;
                        }
                        case 10: {
                            vc.Truck3ax1 = vc.Truck3ax1 + 1;
                            v1.ttxtk = v1.ttxtk + v1.Truck3axle;
                            total = total + v1.Truck3axle;
                            break;
                        }
                        case 11: {
                            vc.Trailer4axle1 = vc.Trailer4axle1 + 1;
                            v1.taftk = v1.taftk + v1.Trailer4axle;
                            total = total + v1.Trailer4axle;
                            break;
                        }
                    }
                }

                vc.calculate();

                v1.SingleCalulate();

                System.out.println("\t\t\t\t\t\t\t\t\t (The total amount of money)= " + total+ " Tk");
            }
            else if (j==3)
                break;
        }

    }

    public void login() {
    }
}

